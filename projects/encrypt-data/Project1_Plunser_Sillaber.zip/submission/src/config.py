# required length of key
KEY_LEN = 16